/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;

/**
 *
 * @author danlin
 */
public class Book {
    protected int bookID;
    protected String bookTitle;
    protected int bookType;
    protected String type;
    protected int num;
    protected int qtyOnHand;
    protected int qtyRented;
    
    public Book(int bookID) {
        this.bookID = bookID;
        this.bookTitle = bookTitle;
        this.bookType = bookType;
        this.type = type;
        this.num = num;
        this.qtyOnHand = qtyOnHand;
        this.qtyRented = qtyRented;
        
        switch(bookID){
            case 0:
                type= "Journal";
                bookTitle= "title1";
                bookType = 1;
                break;
            case 1:
                type= "newspaper";
                bookTitle= "title2";
                bookType = 2;
                break;
            case 2:
                type= "magazine";
                bookTitle= "title3";
                bookType = 3;
                break;
            case 3:
                type= "fairtail";
                bookTitle= "title4";
                bookType = 4;
                break;
        }
    }
    
}
