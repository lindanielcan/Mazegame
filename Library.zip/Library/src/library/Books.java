/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;

import java.util.ArrayList;

/**
 *
 * @author danlin
 */
public class Books {
    
    protected int qtyOnHand;
    protected int qtyRented;

    public Books(int qtyOnHand, int qtyRented) {
        this.qtyOnHand = qtyOnHand;
        this.qtyRented = qtyRented;
        qtyRented = 0;
    }
    
    ArrayList<Book>Books = new ArrayList<Book>();
    
        
    public void addBook(){
            int newBook = 1;
            for(int n = 0; n < 4; n++ ){
            Books.add(new Book(n));
        }}
    
    public void removeBook(){
        int deleteBook = 1;
        Books.remove(deleteBook);}
    
    public void rentBook(int rent){
        if(Books.qtyOnHand-Books.qtyRented > 0){
        }
        
    }
    
    public void returnBook(){
        
    }
    
    public void listBooks(){}
    
}
